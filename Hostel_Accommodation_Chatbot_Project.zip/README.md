# Hostel & Accommodation FAQ Chatbot

A simple NLP-based College FAQ Chatbot for the **Hostel & Accommodation** category.

## Features
- Answers common hostel-related questions
- Uses TF-IDF text representation
- Uses cosine similarity to find the most relevant FAQ
- Provides a fallback response for unknown questions
- Streamlit web interface
- FAQ knowledge base stored in JSON

## Project Structure
```text
hostel_faq_chatbot/
├── app.py
├── faq_data.json
├── requirements.txt
└── README.md
```

## Installation

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Run

```bash
streamlit run app.py
```

Then open the local Streamlit URL shown in the terminal.

## How It Works
1. User enters a question.
2. The question is converted into a TF-IDF vector.
3. The vector is compared with all FAQ-question vectors.
4. Cosine similarity identifies the closest FAQ.
5. If similarity is above the threshold, its answer is returned.
6. Otherwise, the chatbot asks the student to contact the hostel office.

## Customization
Edit `faq_data.json` to replace the sample answers with your college's official hostel rules, fees, contact numbers, timings and facilities.

## GitHub
After creating a GitHub repository, upload all project files and place the repository URL as the final line of the submitted PDF.
