import json
import re
from pathlib import Path

import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

BASE_DIR = Path(__file__).resolve().parent

@st.cache_data
def load_faqs():
    with open(BASE_DIR / "faq_data.json", "r", encoding="utf-8") as f:
        return json.load(f)

faqs = load_faqs()
questions = [item["question"] for item in faqs]

# TF-IDF converts each FAQ question into a numerical vector.
vectorizer = TfidfVectorizer(
    lowercase=True,
    stop_words="english",
    ngram_range=(1, 2)
)
question_vectors = vectorizer.fit_transform(questions)

def clean_text(text):
    text = text.lower().strip()
    text = re.sub(r"\s+", " ", text)
    return text

def get_response(user_query, threshold=0.20):
    query = clean_text(user_query)
    if not query:
        return "Please enter a question."

    query_vector = vectorizer.transform([query])
    scores = cosine_similarity(query_vector, question_vectors)[0]
    best_index = scores.argmax()
    best_score = scores[best_index]

    if best_score < threshold:
        return (
            "I couldn't find a reliable answer to that question. "
            "Please contact the hostel office or warden for institution-specific information."
        )

    return faqs[best_index]["answer"]

st.set_page_config(
    page_title="Hostel & Accommodation FAQ Chatbot",
    page_icon="🏠",
    layout="centered"
)

st.title("🏠 Hostel & Accommodation FAQ Chatbot")
st.caption("Ask questions about hostel admission, rooms, fees, facilities, timings, leave, visitors and complaints.")

if "messages" not in st.session_state:
    st.session_state.messages = [
        {
            "role": "assistant",
            "content": "Hello! I am the Hostel FAQ Chatbot. How can I help you?"
        }
    ]

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])

prompt = st.chat_input("Example: How can I apply for hostel accommodation?")

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.write(prompt)

    answer = get_response(prompt)
    st.session_state.messages.append({"role": "assistant", "content": answer})

    with st.chat_message("assistant"):
        st.write(answer)

with st.sidebar:
    st.header("Quick Questions")
    examples = [
        "What is the hostel fee?",
        "Is Wi-Fi available?",
        "How do I get an out pass?",
        "What facilities are available?",
        "How can I report a complaint?"
    ]
    for q in examples:
        st.write("• " + q)

    st.divider()
    st.write("**Technology:** Python, Streamlit, scikit-learn, TF-IDF, Cosine Similarity")
